# EDA report - `heart_failure_readmission_dataset.csv`

> Source dataset was read-only. Any filtering or exclusions below affect only this EDA output, not the original file.

## Executive summary

- Rows analyzed: **3000** of source **3000**; columns analyzed: **16** of source **16**.
- Target column: **readmitted_30d** (binary).
- Target-aware sections are decision support, not proof; rerun them on a training-only split before final feature selection.
- Column roles: continuous_numeric=9, binary_indicator=4, likely_identifier=1, categorical=1, target=1.
- Target balance ratio: **1.4:1** (balanced).
- Majority-class baseline accuracy: **58.9%** by always predicting `0`.
- Duplicate rows found: **0**.
- Top missingness: `bmi` 3.0%, `sodium` 3.0%, `creatinine` 3.0%.
- Likely identifier columns flagged: `patient_id`.
- Possible data-quality/domain-rule issues found; review before modeling.
- Top numeric effects: `adherence_score` SMD=-0.40, `bnp` SMD=0.33, `age` SMD=0.19.
- Leakage heuristic: no feature tripped the near-perfect predictor rule.

## Decision-grade findings

| finding | decision_status | evidence | recommended_next_step |
| --- | --- | --- | --- |
| identifier_columns | safe to act | patient_id | Exclude these from feature summaries and baseline models unless the user defends a real mechanism. |
| domain_rule_issues | needs domain confirmation | creatinine: possible impossible negative values | Verify values against domain rules before cleaning in a copied dataset. |
| informative_missingness | modeling hypothesis | creatinine missingness changes target rate by -0.115 (95% CI -0.211 to -0.018) | Test a missingness-indicator feature inside cross-validation. |
| strongest_numeric_signal | modeling hypothesis | adherence_score SMD=-0.401, AUC=0.386 | Prioritize this feature for sanity checks, transformations, or binning before weaker signals. |
| strongest_binary_signal | modeling hypothesis | ace_inhibitor OR=0.684, risk difference=-0.092 | Check whether the direction makes domain sense and test it in a leak-safe baseline. |
| risk_gradient | modeling hypothesis | adherence_score is mostly decreasing risk with target-rate spread 0.269 | Use bins or monotonic transforms only if the gradient is stable in training-only EDA. |
| two_feature_risk_slice | modeling hypothesis | adherence_score=(0.399, 0.61]; bnp=(511.333, 1381.0] has target rate 0.656 (lift 0.245) | Treat as a candidate interaction or segmentation idea; confirm inside training-only validation. |

Use this table as the short list of what is safe to act on, what needs domain confirmation, and what is only a modeling hypothesis.

## Key plots

![Target balance](plots/target_balance.png)

*Use this to decide whether accuracy is meaningful or whether imbalance-aware metrics are needed.*

![Missingness by column](plots/missingness.png)

*Missing bars show where imputation, missingness indicators, or data collection questions may matter.*

![Correlation heatmap](plots/correlation_heatmap.png)

*Numeric-measurement Pearson correlations; target, likely identifiers, and yes/no indicators are excluded so this shows measurement redundancy.*

![Top numeric target relationship](plots/target_numeric_adherence_score.png)

*Boxplots show whether a numeric feature separates target groups; use the effect-size table below for magnitude.*

![Top numeric target relationship](plots/target_numeric_bnp.png)

*Boxplots show whether a numeric feature separates target groups; use the effect-size table below for magnitude.*

![Top numeric target relationship](plots/target_numeric_age.png)

*Boxplots show whether a numeric feature separates target groups; use the effect-size table below for magnitude.*

![Top categorical target relationship](plots/target_categorical_ace_inhibitor.png)

*Bars show target rate by level; wide confidence intervals or tiny groups should lower confidence.*

![Top categorical target relationship](plots/target_categorical_beta_blocker.png)

*Bars show target rate by level; wide confidence intervals or tiny groups should lower confidence.*

![Binned target-rate gradient](plots/risk_gradient_adherence_score.png)

*Binned rates test whether a numeric signal changes smoothly across values or only in one odd slice.*

![Binned target-rate gradient](plots/risk_gradient_bnp.png)

*Binned rates test whether a numeric signal changes smoothly across values or only in one odd slice.*

Additional plots are saved under `plots/`.

## Target class balance

| class | count | proportion |
|---|---|---|
| 0 | 1766 | 0.5887 |
| 1 | 1234 | 0.4113 |

Majority:minority ratio ~ **1.4:1** (balanced).
Majority-class baseline accuracy: **58.9%** if a model always predicts `0`. Any accuracy score should be judged against this floor, not against zero.

## Column roles

| column | role | dtype | pct_missing | n_unique | unique_ratio | note |
| --- | --- | --- | --- | --- | --- | --- |
| patient_id | likely_identifier | int64 | 0.0 | 3000 | 1.0 | Row label or key; exclude from regular feature summaries and modeling. |
| age | continuous_numeric | int64 | 0.0 | 51 | 0.017 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| gender | binary_indicator | str | 0.0 | 2 | 0.001 | Two-level feature; report rates/odds ratios when a binary target exists. |
| bmi | continuous_numeric | float64 | 3.0 | 264 | 0.088 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| bnp | continuous_numeric | int64 | 0.0 | 818 | 0.273 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| sodium | continuous_numeric | float64 | 3.0 | 217 | 0.072 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| creatinine | continuous_numeric | float64 | 3.0 | 262 | 0.087 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| systolic_bp | continuous_numeric | int64 | 0.0 | 120 | 0.04 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| heart_rate | continuous_numeric | int64 | 0.0 | 92 | 0.031 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| ace_inhibitor | binary_indicator | int64 | 0.0 | 2 | 0.001 | Two-level feature; report rates/odds ratios when a binary target exists. |
| beta_blocker | binary_indicator | int64 | 0.0 | 2 | 0.001 | Two-level feature; report rates/odds ratios when a binary target exists. |
| diuretic | binary_indicator | int64 | 0.0 | 2 | 0.001 | Two-level feature; report rates/odds ratios when a binary target exists. |
| adherence_score | continuous_numeric | float64 | 0.0 | 61 | 0.02 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| income_level | categorical | str | 0.0 | 3 | 0.001 | Nominal/ordinal-looking feature candidate. |
| distance_to_hospital_km | continuous_numeric | float64 | 0.0 | 490 | 0.163 | Numeric feature candidate; inspect distribution, outliers, and target gradient. |
| readmitted_30d | target | int64 | 0.0 | 2 | 0.001 | Outcome column; summarize separately and never use as a feature. |

Role classification keeps identifiers and the target out of sections where they would create fake signal.

## Column inventory

| column | dtype | % missing | n unique |
|---|---|---|---|
| patient_id | int64 | 0.0 | 3000 |
| age | int64 | 0.0 | 51 |
| gender | str | 0.0 | 2 |
| bmi | float64 | 3.0 | 264 |
| bnp | int64 | 0.0 | 818 |
| sodium | float64 | 3.0 | 217 |
| creatinine | float64 | 3.0 | 262 |
| systolic_bp | int64 | 0.0 | 120 |
| heart_rate | int64 | 0.0 | 92 |
| ace_inhibitor | int64 | 0.0 | 2 |
| beta_blocker | int64 | 0.0 | 2 |
| diuretic | int64 | 0.0 | 2 |
| adherence_score | float64 | 0.0 | 61 |
| income_level | str | 0.0 | 3 |
| distance_to_hospital_km | float64 | 0.0 | 490 |
| readmitted_30d | int64 | 0.0 | 2 |

## Likely identifier columns

| column | n_unique | unique_ratio | reason |
| --- | --- | --- | --- |
| patient_id | 3000 | 1.0 | name looks like an identifier |

Treat these as row labels or grouping keys unless you can defend them as real predictive features.

## Numeric measurement summary

|  | mean | std | min | 50% | max | skew | kurtosis |
| --- | --- | --- | --- | --- | --- | --- | --- |
| age | 65.254 | 14.806 | 40.0 | 65.0 | 90.0 | -0.034 | -1.238 |
| bmi | 28.109 | 4.949 | 8.8 | 28.1 | 44.9 | -0.053 | -0.088 |
| bnp | 406.308 | 232.273 | 50.0 | 392.0 | 1381.0 | 0.346 | -0.415 |
| sodium | 138.089 | 4.032 | 124.7 | 138.1 | 151.6 | 0.036 | -0.068 |
| creatinine | 1.195 | 0.491 | -0.59 | 1.2 | 2.94 | 0.027 | 0.009 |
| systolic_bp | 129.589 | 20.257 | 61.0 | 130.0 | 196.0 | -0.104 | 0.011 |
| heart_rate | 79.364 | 15.269 | 19.0 | 79.0 | 147.0 | -0.025 | -0.009 |
| adherence_score | 0.699 | 0.173 | 0.4 | 0.7 | 1.0 | 0.023 | -1.171 |
| distance_to_hospital_km | 25.4 | 14.146 | 1.0 | 25.45 | 50.0 | 0.004 | -1.196 |

Target, likely identifier columns, and binary yes/no indicators are excluded from this table.

## Numeric measurement outliers (1.5xIQR fence)

| column | n_outliers | pct_outliers | iqr_low | iqr_high |
| --- | --- | --- | --- | --- |
| creatinine | 25 | 0.86 | -0.105 | 2.495 |
| systolic_bp | 22 | 0.73 | 75.5 | 183.5 |
| sodium | 18 | 0.62 | 127.05 | 149.05 |
| heart_rate | 17 | 0.57 | 37.5 | 121.5 |
| bmi | 15 | 0.52 | 14.75 | 41.55 |
| bnp | 8 | 0.27 | -291.0 | 1085.0 |
| age | 0 | 0.0 | 13.0 | 117.0 |
| adherence_score | 0 | 0.0 | 0.1 | 1.3 |
| distance_to_hospital_km | 0 | 0.0 | -24.287 | 74.612 |

Outlier flags are prompts for review, not instructions to delete rows.

## Possible data-quality/domain-rule issues

| column | issue | n_rows | min_value |
| --- | --- | --- | --- |
| creatinine | possible impossible negative values | 18 | -0.59 |

These are general heuristics based on column names and values. Verify with domain knowledge before cleaning.

## Data-quality action plan

| issue | severity | evidence | suggested_action | risk_if_ignored |
| --- | --- | --- | --- | --- |
| creatinine | high | possible impossible negative values in 18 row(s); min=-0.59 | Verify with domain knowledge. If cleaning is needed, write a copied cleaned dataset. | Impossible values can distort means, correlations, tests, and model splits. |

Any cleaning action should be applied to a copied dataset or a reproducible cleaning script, never by overwriting the original source file.

## Missingness review

| column | n_missing | pct_missing | target_rate_when_missing | target_rate_when_present | delta | delta_95ci_low | delta_95ci_high | confidence_note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| bmi | 90 | 3.0 | 0.4111 | 0.4113 | -0.0002 | -0.1034 | 0.103 | small missing group; treat cautiously |
| sodium | 90 | 3.0 | 0.3556 | 0.4131 | -0.0575 | -0.158 | 0.043 | small missing group; treat cautiously |
| creatinine | 90 | 3.0 | 0.3 | 0.4148 | -0.1148 | -0.2111 | -0.0184 | small missing group; treat cautiously |

The delta columns compare missing rows with present rows. A confidence interval crossing 0 means the apparent difference may just be sampling noise; small missing groups deserve extra skepticism.

## Missingness patterns

| missing_pattern | n_rows | pct_rows | target_rate | lift_vs_base |
| --- | --- | --- | --- | --- |
| (none) | 2740 | 91.33 | 0.4172 | 0.0058 |
| bmi | 85 | 2.83 | 0.3882 | -0.0231 |
| creatinine | 85 | 2.83 | 0.3059 | -0.1055 |
| sodium | 80 | 2.67 | 0.3375 | -0.0738 |
| bmi + sodium | 5 | 0.17 | 0.8 | 0.3887 |
| sodium + creatinine | 5 | 0.17 | 0.2 | -0.2113 |

Patterns show whether missing values tend to happen alone or in clusters. A cluster can mean one data-collection step failed, not several unrelated variables failed independently.

## Effect sizes and uncertainty

### Numeric effects

| feature | negative_class | positive_class | n_negative | n_positive | mean_negative | mean_positive | difference_pos_minus_neg | diff_95ci_low | diff_95ci_high | standardized_mean_difference | univariate_auc |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| adherence_score | 0 | 1 | 1766 | 1234 | 0.7274 | 0.6593 | -0.0681 | -0.0806 | -0.0556 | -0.4012 | 0.3856 |
| bnp | 0 | 1 | 1766 | 1234 | 374.9881 | 451.1305 | 76.1424 | 59.2978 | 92.9869 | 0.3321 | 0.5974 |
| age | 0 | 1 | 1766 | 1234 | 64.1217 | 66.8752 | 2.7535 | 1.6792 | 3.8277 | 0.1867 | 0.5538 |
| distance_to_hospital_km | 0 | 1 | 1766 | 1234 | 24.6071 | 26.5335 | 1.9264 | 0.9055 | 2.9473 | 0.1365 | 0.5393 |
| sodium | 0 | 1 | 1708 | 1202 | 138.2624 | 137.8431 | -0.4193 | -0.7198 | -0.1189 | -0.1041 | 0.4639 |
| creatinine | 0 | 1 | 1703 | 1207 | 1.178 | 1.2192 | 0.0412 | 0.0048 | 0.0776 | 0.084 | 0.5294 |
| systolic_bp | 0 | 1 | 1766 | 1234 | 128.9949 | 130.4384 | 1.4435 | -0.0154 | 2.9024 | 0.0713 | 0.5186 |
| bmi | 0 | 1 | 1713 | 1197 | 27.9921 | 28.2764 | 0.2842 | -0.081 | 0.6495 | 0.0574 | 0.5203 |
| heart_rate | 0 | 1 | 1766 | 1234 | 79.5232 | 79.1361 | -0.3871 | -1.4978 | 0.7237 | -0.0253 | 0.493 |

Standardized mean difference is the class-mean gap measured in standard-deviation units. Roughly: 0.2 small, 0.5 medium, 0.8 large. AUC is the chance a random positive-class row has a higher feature value than a random negative-class row.

### Binary-feature effects

| feature | level_compared | reference_level | n_compared | n_reference | target_rate_compared | target_rate_reference | risk_difference | risk_diff_95ci_low | risk_diff_95ci_high | odds_ratio | odds_ratio_95ci_low | odds_ratio_95ci_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ace_inhibitor | 1 | 0 | 1565 | 1435 | 0.3674 | 0.4592 | -0.0918 | -0.127 | -0.0567 | 0.6839 | 0.591 | 0.7915 |
| beta_blocker | 1 | 0 | 1510 | 1490 | 0.3695 | 0.4537 | -0.0842 | -0.1193 | -0.0491 | 0.7058 | 0.6099 | 0.8168 |
| diuretic | 1 | 0 | 1467 | 1533 | 0.4192 | 0.4038 | 0.0154 | -0.0198 | 0.0507 | 1.0658 | 0.9215 | 1.2327 |
| gender | Male | Female | 1508 | 1492 | 0.4118 | 0.4109 | 0.0009 | -0.0343 | 0.0362 | 1.0039 | 0.868 | 1.1611 |

Odds ratio compares odds, not raw probability. Values above 1 mean the compared level is associated with higher target odds; below 1 means lower target odds.

## Target-aware numeric signals

| feature | mean_target_0 | mean_target_1 | difference | univariate_auc | direction |
| --- | --- | --- | --- | --- | --- |
| adherence_score | 0.7274 | 0.6593 | -0.0681 | 0.3856 | lower for target=1 |
| bnp | 374.9881 | 451.1305 | 76.1424 | 0.5974 | higher for target=1 |
| age | 64.1217 | 66.8752 | 2.7535 | 0.5538 | higher for target=1 |
| distance_to_hospital_km | 24.6071 | 26.5335 | 1.9264 | 0.5393 | higher for target=1 |
| sodium | 138.2624 | 137.8431 | -0.4193 | 0.4639 | lower for target=1 |
| creatinine | 1.178 | 1.2192 | 0.0412 | 0.5294 | higher for target=1 |
| bmi | 27.9921 | 28.2764 | 0.2842 | 0.5203 | higher for target=1 |
| systolic_bp | 128.9949 | 130.4384 | 1.4435 | 0.5186 | higher for target=1 |
| heart_rate | 79.5232 | 79.1361 | -0.3871 | 0.493 | lower for target=1 |

These are univariate views. They help choose what to inspect next, not what to trust blindly.

## Risk gradients / binned target rates

### Trend summary

| feature | n_bins | lowest_bin_rate | highest_bin_rate | rate_spread | trend_corr | pattern |
| --- | --- | --- | --- | --- | --- | --- |
| adherence_score | 5 | 0.3231 | 0.5925 | 0.2694 | -0.8985 | mostly decreasing risk |
| bnp | 5 | 0.3317 | 0.5643 | 0.2326 | 0.9189 | mostly increasing risk |
| sodium | 5 | 0.3683 | 0.4966 | 0.1283 | -0.7321 | mixed / non-monotonic |
| distance_to_hospital_km | 5 | 0.3478 | 0.469 | 0.1213 | 0.7987 | mostly increasing risk |
| age | 5 | 0.3645 | 0.4751 | 0.1107 | 0.9442 | mostly increasing risk |

The trend summary compresses each binned table into a plain-language pattern. Mixed trends are still useful, but they are worse candidates for simple linear assumptions.

### adherence_score

| bin | n | feature_min | feature_max | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| (0.399, 0.52] | 611 | 0.4 | 0.52 | 0.5925 | 0.553 | 0.6307 | 0.1811 |
| (0.52, 0.64] | 619 | 0.53 | 0.64 | 0.454 | 0.4151 | 0.4933 | 0.0426 |
| (0.64, 0.75] | 573 | 0.65 | 0.75 | 0.3386 | 0.301 | 0.3783 | -0.0728 |
| (0.75, 0.88] | 612 | 0.76 | 0.88 | 0.3399 | 0.3034 | 0.3783 | -0.0715 |
| (0.88, 1.0] | 585 | 0.89 | 1.0 | 0.3231 | 0.2864 | 0.362 | -0.0883 |
### bnp

| bin | n | feature_min | feature_max | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| (49.999, 186.8] | 600 | 50 | 186 | 0.3317 | 0.2952 | 0.3703 | -0.0797 |
| (186.8, 326.0] | 604 | 187 | 326 | 0.3411 | 0.3044 | 0.3798 | -0.0703 |
| (326.0, 464.0] | 599 | 327 | 464 | 0.3506 | 0.3134 | 0.3896 | -0.0607 |
| (464.0, 611.0] | 598 | 465 | 611 | 0.4699 | 0.4302 | 0.51 | 0.0586 |
| (611.0, 1381.0] | 599 | 612 | 1381 | 0.5643 | 0.5243 | 0.6034 | 0.1529 |
### age

| bin | n | feature_min | feature_max | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| (39.999, 50.0] | 665 | 40 | 50 | 0.3669 | 0.3311 | 0.4042 | -0.0444 |
| (50.0, 60.0] | 557 | 51 | 60 | 0.3645 | 0.3255 | 0.4052 | -0.0469 |
| (60.0, 71.0] | 613 | 61 | 71 | 0.3948 | 0.3569 | 0.434 | -0.0166 |
| (71.0, 81.0] | 622 | 72 | 81 | 0.4614 | 0.4226 | 0.5007 | 0.0501 |
| (81.0, 90.0] | 543 | 82 | 90 | 0.4751 | 0.4335 | 0.5172 | 0.0638 |
### distance_to_hospital_km

| bin | n | feature_min | feature_max | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| (0.999, 10.6] | 601 | 1.0 | 10.6 | 0.3478 | 0.3108 | 0.3867 | -0.0636 |
| (10.6, 20.6] | 602 | 10.7 | 20.6 | 0.3937 | 0.3555 | 0.4333 | -0.0176 |
| (20.6, 30.2] | 604 | 20.7 | 30.2 | 0.4238 | 0.385 | 0.4636 | 0.0125 |
| (30.2, 40.1] | 597 | 30.3 | 40.1 | 0.469 | 0.4293 | 0.5091 | 0.0577 |
| (40.1, 50.0] | 596 | 40.2 | 50.0 | 0.4228 | 0.3838 | 0.4629 | 0.0115 |
### sodium

| bin | n | feature_min | feature_max | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| (124.699, 134.6] | 588 | 124.7 | 134.6 | 0.4966 | 0.4563 | 0.5369 | 0.0853 |
| (134.6, 137.1] | 596 | 134.7 | 137.1 | 0.4211 | 0.3821 | 0.4612 | 0.0098 |
| (137.1, 139.04] | 562 | 137.2 | 139.0 | 0.3683 | 0.3295 | 0.409 | -0.043 |
| (139.04, 141.5] | 584 | 139.1 | 141.5 | 0.3767 | 0.3383 | 0.4167 | -0.0346 |
| (141.5, 151.6] | 580 | 141.6 | 151.6 | 0.4 | 0.3609 | 0.4404 | -0.0113 |

Binned target rates help distinguish a stable trend from one weird outlier band. Choose bins before final testing, or estimate them inside training folds.

## Top two-feature risk slices

| feature_pair | slice | n | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- |
| adherence_score + bnp | adherence_score=(0.399, 0.61]; bnp=(511.333, 1381.0] | 375 | 0.656 | 0.6066 | 0.7023 | 0.2447 |
| adherence_score + sodium | adherence_score=(0.399, 0.61]; sodium=(124.699, 136.3] | 332 | 0.6446 | 0.5917 | 0.6941 | 0.2332 |
| adherence_score + age | adherence_score=(0.399, 0.61]; age=(74.0, 90.0] | 352 | 0.6051 | 0.5532 | 0.6548 | 0.1938 |
| adherence_score + ace_inhibitor | adherence_score=(0.399, 0.61]; ace_inhibitor=0 | 515 | 0.6039 | 0.561 | 0.6452 | 0.1926 |
| adherence_score + distance_to_hospital_km | adherence_score=(0.399, 0.61]; distance_to_hospital_km=(33.5, 50.0] | 349 | 0.6017 | 0.5495 | 0.6517 | 0.1904 |
| bnp + sodium | bnp=(511.333, 1381.0]; sodium=(124.699, 136.3] | 325 | 0.5938 | 0.5397 | 0.6458 | 0.1825 |
| adherence_score + bnp | adherence_score=(0.61, 0.79]; bnp=(49.999, 286.0] | 305 | 0.2295 | 0.1859 | 0.2799 | -0.1818 |
| adherence_score + beta_blocker | adherence_score=(0.399, 0.61]; beta_blocker=0 | 528 | 0.589 | 0.5466 | 0.6302 | 0.1777 |
| bnp + beta_blocker | bnp=(511.333, 1381.0]; beta_blocker=0 | 505 | 0.5822 | 0.5387 | 0.6244 | 0.1708 |
| adherence_score + diuretic | adherence_score=(0.399, 0.61]; diuretic=1 | 518 | 0.5792 | 0.5362 | 0.6209 | 0.1678 |
| bnp + distance_to_hospital_km | bnp=(511.333, 1381.0]; distance_to_hospital_km=(33.5, 50.0] | 332 | 0.5783 | 0.5246 | 0.6302 | 0.167 |
| bnp + age | bnp=(511.333, 1381.0]; age=(74.0, 90.0] | 337 | 0.5697 | 0.5164 | 0.6215 | 0.1584 |

These slices screen for combinations that move risk more than either feature alone. They are interaction hypotheses, not final rules; confirm them on training-only data with cross-validation.

## Target-aware categorical signals

| feature | level | n | n_with_target | target_rate | target_rate_95ci_low | target_rate_95ci_high | lift_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ace_inhibitor | 0 | 1435 | 1435 | 0.4592 | 0.4336 | 0.4851 | 0.0479 |
| ace_inhibitor | 1 | 1565 | 1565 | 0.3674 | 0.3439 | 0.3916 | -0.0439 |
| beta_blocker | 0 | 1490 | 1490 | 0.4537 | 0.4286 | 0.4791 | 0.0424 |
| beta_blocker | 1 | 1510 | 1510 | 0.3695 | 0.3456 | 0.3942 | -0.0418 |
| income_level | High | 978 | 978 | 0.4029 | 0.3726 | 0.4339 | -0.0085 |
| diuretic | 1 | 1467 | 1467 | 0.4192 | 0.3942 | 0.4447 | 0.0079 |
| diuretic | 0 | 1533 | 1533 | 0.4038 | 0.3795 | 0.4286 | -0.0075 |
| income_level | Low | 1024 | 1024 | 0.417 | 0.3872 | 0.4474 | 0.0057 |
| income_level | Medium | 998 | 998 | 0.4138 | 0.3837 | 0.4447 | 0.0025 |
| gender | Female | 1492 | 1492 | 0.4109 | 0.3862 | 0.436 | -0.0005 |
| gender | Male | 1508 | 1508 | 0.4118 | 0.3872 | 0.4368 | 0.0005 |

## Most correlated numeric measurement pairs

| feature A | feature B | Pearson r |
|---|---|---|
| sodium | adherence_score | -0.045 |
| bnp | creatinine | -0.041 |
| bmi | adherence_score | -0.039 |
| systolic_bp | adherence_score | -0.036 |
| age | sodium | -0.032 |
| bnp | adherence_score | -0.031 |
| bmi | heart_rate | 0.029 |
| sodium | creatinine | -0.026 |
| age | bnp | 0.024 |
| bnp | distance_to_hospital_km | 0.021 |

Target, likely identifier columns, and binary yes/no indicators are excluded so this section focuses on measurement redundancy.

## Possible target leakage

No features tripped the near-perfect predictor heuristic. Absence of evidence is not evidence of absence; still verify feature availability before modeling.

## Feature engineering paths to test

| priority | candidate_path | evidence | risk_or_caution | how_to_test |
| --- | --- | --- | --- | --- |
| P0 | Resolve impossible/domain-rule values before feature engineering | Potential impossible values in creatinine. | Cleaning choices can dominate downstream effects. | Create a copied cleaned dataset and rerun EDA before modeling. |
| P1 | Add missingness indicators | Missingness changes target behavior for creatinine. | May encode workflow artifacts instead of biology/business reality. | Compare CV baseline with and without indicators. |
| P1 | Try binned or monotonic form of adherence_score | Target rate changes by 0.269 across bins. | Bins can overfit if chosen after looking at the full dataset. | Define bins inside training folds or pre-specify bins, then compare CV metrics. |
| P2 | Test a small interaction or subgroup feature | Top two-feature slice: adherence_score=(0.399, 0.61]; bnp=(511.333, 1381.0] has lift 0.245. | Subgroups can overfit fast if picked from the full dataset. | Predefine the interaction from training-only EDA, then compare CV performance against the baseline. |
| P2 | Prioritize strongest numeric signals | Moderate-or-larger standardized differences for adherence_score, bnp. | Single-feature effects may disappear after adjustment for other variables. | Add one small feature batch at a time and compare against the baseline. |
| P2 | Keep/test meaningful binary indicators | Odds ratios differ from 1 for ace_inhibitor, beta_blocker. | Association is not causation; direction can reflect confounding. | Compare models with these indicators and inspect coefficient/importance stability. |

Treat these as experiments, not chores. The value comes from testing a small number of plausible changes against a baseline.

## Recommended actions ranked by priority

| priority | action | evidence | next_step |
| --- | --- | --- | --- |
| P0 | Resolve high-severity data-quality issues | creatinine | Create a copied cleaned dataset, then rerun EDA. |
| P1 | Exclude likely identifiers from modeling | patient_id | Pass them through only as row labels or grouping keys. |
| P1 | Choose the evaluation metric before modeling | False positives and false negatives usually do not cost the same. | Write down the metric and threshold-selection rule before tuning. |
| P2 | Test the strongest EDA hypotheses | informative_missingness; strongest_numeric_signal; strongest_binary_signal | Use training-only EDA and cross-validation, not the final test set. |
| P3 | Reserve the final test set from decision-making | Target-aware EDA can accidentally teach you the test set. | Use the final test set once, after cleaning and model selection decisions are locked. |

## What not to do yet

- Do not overwrite the original dataset while cleaning; write a copied cleaned dataset or reproducible cleaning script.
- Do not use likely identifiers as regular predictive features unless there is a defensible real-world mechanism.
- Do not treat target-aware EDA on the full dataset as final proof; repeat key checks on the training split.
- Do not delete outliers only because the IQR rule flagged them; first decide whether they are errors or rare valid cases.
- Do not engineer every suggested feature at once; add small batches so you can tell what helped.
- Do not rely on accuracy alone until the metric matches the cost of false positives and false negatives.
